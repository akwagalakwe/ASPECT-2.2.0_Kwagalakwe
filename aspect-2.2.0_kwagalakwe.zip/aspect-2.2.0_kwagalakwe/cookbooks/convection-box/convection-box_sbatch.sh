#!/bin/bash

#SBATCH -N1
#SBATCH --ntasks-per-node=128
#SBATCH -t 30:00
#SBATCH -p normal_q
#SBATCH -A mantlith

#load module
module reset
module load CMake/3.16.4-intel-2019b
module load Lua python2
module load tinkercliffs-rome/dealii-9.2.0/intel-2019b
export ASPECT_SOURCE_DIR=/work/asenathk/aspect-2.2.0_njinju_etal_2021
export ASPECT_INSTALL_DIR=/work/asenathk/aspect-2.2.0_njinju_etal_2021/build
MPICXX=`which mpicxx`
MPICC=`which mpicc`
MPIF90=`which mpif90`

#cd into correct directory
cd /work/asenathk/aspect-2.2.0_njinju_etal_2021/cookbooks/convection-box

# run aspect
/work/asenathk/aspect-2.2.0_njinju_etal_2021/build/aspect convection-box.prm
