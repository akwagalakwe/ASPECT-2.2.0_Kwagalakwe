1. This README file describes the content of aspect-2.2.0_kwagalakwe.zip, which is a supplement to the manuscript "Investigating Melt Generation Beneath the Northern Western Branch of the East African Rift System Using 3D Geodynamic Modeling with ASPECT" submitted to Tectonophysics in June 2023.

2. All files and folders are provided to compile ASPECT version 2.2.0.

3. The file edc_melting.cc (Njinju et al., 2021; Njinju, 2022) is provided in the folder source/material_model.

4. Changes from ASPECT version 2.2.0 include lithospheric thickness files for LITHO1.0 (Pasyanos et al., 2014); the Afonso model (Afonso et al., 2022); and the Fishwick model (Fishwick (2010, revised)). These lithospheric thickness files are provided in the folder data/initial-temperature/adiabatic-boundary/. When you are ready to use any of the lithospheric thickness files, copy the file to adiabatic_boundary.txt because of a bug in the code.

5. In this manuscript, several changes were made to the parameters in material_model/edc_melting.cc from those of Njinju et al., 2021; Njinju, 2022, specifically the following:

*Reference density changed to 3300 kg/m^3
*Thermal conductivity changed to 4.0 W/mK
*Lithospheric viscosity changed to 1e25 Pa.s
*Thermal expansion coefficient changed to 3e-5 1/K
*Grain size changed to 1e-2
*Maximum viscosity changed to 1e25 Pa.s
*Activation energy for diffusion creep changed to 3.75e5 J/mol
*Prefactor for diffusion creep changed to 1.5e-15
*Activation energy for dislocation creep changed to 5.3e5 J/mol
*Activation volume for dislocation creep changed to 18e-6 m^3/mol
*Stress exponent for dislocation creep changed to 3.5
*Prefactor for dislocation creep changed to 6.52e-16
*Reference compressibility changed to 5.124e-12 1/Pa

5. There is a directory called prm_files that contains all the parameter files needed to reproduce this work. Note that you will need to update the path for your output directory and replace the adiabatic_boundary.txt file with the appropriate lithospheric thickness file. For the subsection Ascii data model, we have included the proper information in our prm files; however, because of the bug, you still need to copy the appropriate lithospheric thickness file to adiabatic_boundary.txt in the folder data/initial-temperature/adiabatic-boundary/.


